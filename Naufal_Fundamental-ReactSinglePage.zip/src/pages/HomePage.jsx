import NoteList from '../components/NoteList';
import SearchBar from '../components/SearchBar';
import { getAllNotes, deleteNote } from '../utils/local-data';
import { FiPlusCircle } from 'react-icons/fi';
import { Link } from 'react-router-dom';

function HomePage() {
  const notes = getAllNotes();

  // Function to delete a note
  const onDelete = (id) => {
    deleteNote(id);
  };

  return (
    <div>
      <h2>Catatan Aktif</h2>
      <SearchBar />
      <NoteList notes={notes} onDelete={onDelete} />
      <div className='homepage__action'>
      <Link to="/notes/new" className='action'><FiPlusCircle /></Link>
      </div>
    </div>
  );
} 


export default HomePage;

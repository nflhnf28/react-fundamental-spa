import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { addNote } from '../utils/local-data';
import NewNoteTitle from '../components/NewNoteTitle';
import NewNoteBody from '../components/NewNoteBody';
import { FiCheck } from 'react-icons/fi';

function AddNotePage() {
  const [titleContent, setTitleContent] = useState('');
  const [bodyContent, setBodyContent] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault();

    // Generate unique ID for the new note
    const id = `notes-${+new Date()}`;

    // Create new note object
    const newNote = {
      id,
      title: titleContent,
      body: bodyContent, 
      archived: false,
      createdAt: new Date().toISOString(),
    };

    // Add the new note
    addNote(newNote);

    // Navigate to home page after adding the note
    navigate('/');
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <NewNoteTitle setTitleContent={setTitleContent} />
        <NewNoteBody bodyContent={bodyContent} setBodyContent={setBodyContent} />
        <div className='homepage__action'>
          <button type="submit" className='action'><FiCheck /></button>
        </div>
      </form>
    </div>
  );
}

export default AddNotePage;

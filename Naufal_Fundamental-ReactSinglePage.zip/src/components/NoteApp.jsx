import { useState } from 'react';
import { Link } from 'react-router-dom'
import { getAllNotes, deleteNote } from '../utils/local-data';
import { Routes, Route } from 'react-router-dom';
import DetailPage from './DetailPage';
import HomePage from '../pages/HomePage';
import AddNotePage from '../pages/AddNotePage';

function NoteApp() {
  const [notes, setNotes] = useState(getAllNotes()); // Initialize notes state with all notes

  // Function to delete a note
  const onDelete = (id) => {
    deleteNote(id); // Call deleteNote function to delete the note
    setNotes(notes.filter(note => note.id !== id)); // Update notes state after deletion
  };
  
  return (
    <div className='app-container'>
      <header>
      <h1><Link to="/">Aplikasi Catatan</Link></h1>
        <nav className='navigation'>
          <ul>
            <li>
              <Link to='/archives'>Arsip</Link>
            </li>
          </ul>
        </nav>
      </header>

      <main>
        <Routes>
          <Route path="/notes/new" element={<AddNotePage />} />
          <Route path="/" element={<HomePage />} />
          <Route path="/detail/:id" element={<DetailPage onDelete={onDelete} />} />
        </Routes>
      </main>
    </div>
  )
}

export default NoteApp;

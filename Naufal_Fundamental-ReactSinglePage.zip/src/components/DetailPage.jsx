import { useParams, useNavigate } from 'react-router-dom';
import { getNote } from '../utils/local-data';
import PropTypes from 'prop-types';
import { FiTrash2 } from 'react-icons/fi';
import { showFormattedDate } from '../utils/index.js';

function DetailPage({ onDelete }) {
  const { id } = useParams();
  const navigate = useNavigate();

  const handleDelete = () => {
    onDelete(id);
    navigate('/');
  };


  if (!id) {
    return <div>No note ID provided</div>;
  }

  const note = getNote(id);

  if (!note) {
    return <div>Note not found</div>;
  }

  return (
    <div>
      <h2>{note.title}</h2>
      <p>{showFormattedDate(note.createdAt)}</p>
      <p>{note.body}</p>
      
      <div className='homepage__action'>
        <button onClick={handleDelete} className='action'><FiTrash2 /></button>    
      </div>
    </div>
  );
}

DetailPage.propTypes = {
  onDelete: PropTypes.func.isRequired,
};

export default DetailPage;
